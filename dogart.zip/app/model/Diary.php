<?php
namespace app\model;


use think\Model;

class Diary extends Model
{

}